# Candidatura a Bolsa de Iniciação à Investigação BL155/2021 - Exercício Prático

## Inicialização de um servidor local de testes

Este documento serve para explicar o procedimento de inicializar um servidor de testes.

--- 

Para inicializar o servidor, é necessário que a máquina esteja equipada com:

* [python 3.8.10](https://www.python.org/downloads/) ou superior;
* Framework [Django](https://docs.djangoproject.com/en/3.2/topics/install/#installing-official-release) 3.2.7 (versão mais recente);
* Módulo [requests](https://docs.python-requests.org/en/latest/) 2.26 (versão mais recente);

Quando as dependências estiveram instaladas, num terminal, entrar no diretório mais exterior (`DEIParty/`) e correr o comando  
`python3 manage.py runserver`.  

Mantenha o terminal aberto e, através de um browser, aceda ao link `127.0.0.1:8000/DEIParty_app/`.