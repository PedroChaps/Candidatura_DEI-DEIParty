import requests
from DEIParty.settings import API_URLS, ERROR, ACCESS_TOKEN

# .. Delete this
BASE_URL = "https://aduck.rnl.tecnico.ulisboa.pt/deiparty"
# The convention is {"objective": (url, method)}
API_URLS = {
    "LIST_BEVERAGES": BASE_URL + "/beverages",
    "CREATE_BEVERAGES": BASE_URL + "/beverages",
    "REMOVE_BEVERAGES": BASE_URL + "/beverages/{beverageId}",
    "INFO_BEVERAGE": BASE_URL + "/beverages/{beverageId}",
    "UPDATE_BEVERAGE": BASE_URL + "/beverages/{beverageId}"
}


def list_all_beverages(limit, offset):

    url = API_URLS["LIST_BEVERAGES"]
    params = {"limit": limit, "offset": offset}

    r = requests.get(url, params)

    if r.ok:
        return r.json()
    else:
        return ERROR


def get_beverage_info(id):

    url = API_URLS["INFO_BEVERAGE"].replace("{beverageId}", str(id))

    r = requests.get(url)

    if r.ok:
        return r.json()
    else:
        return ERROR


def process_removal(id):

    url = API_URLS["REMOVE_BEVERAGES"].replace("{beverageId}", str(id))

    r = requests.delete(
        url, headers={"Authorization": "Bearer " + ACCESS_TOKEN})

    return r.status_code


def process_update(id, new_quantity):

    url = API_URLS["UPDATE_BEVERAGE"].replace("{beverageId}", str(id))
    beverage = get_beverage_info(id)

    print("\n\nurl =", url, "\nbeverage =", beverage)

    new_beverage = beverage
    new_beverage["amountInStock"] = new_quantity

    headers = {
        "accept": "application/json",
        "Authorization": "Bearer " + ACCESS_TOKEN,
        "Content-Type": "application/json"
    }

    r = requests.put(url, json=new_beverage, headers=headers)

    return r.status_code


def process_new_bev(request):
    url = API_URLS["CREATE_BEVERAGES"]

    info = request.POST

    params = {
        "id": int(info["id"]),
        "designation": info["designation"],
        "amountInStock": int(info["amountInStock"]),
        "imageUrl": info["imageUrl"],
        "supplier": info["supplier"]
    }

    headers = {
        "accept": "application/json",
        "Authorization": "Bearer " + ACCESS_TOKEN,
        "Content-Type": "application/json"
    }

    r = requests.post(url, json=params, headers=headers)

    print("\n\n\nparams =", params, "\nr info = ", r.text)
    return r.status_code


# url = API_URLS["CREATE_BEVERAGES"]

#     info = request.POST

#     params = {
#         "id": info["id"],
#         "designation": info["designation"],
#         "amountInStock": info["amountInStock"],
#         "imageUrl": info["imageUrl"],
#         "supplier": info["supplier"]
#     }

#     print("\n\n\n", url, "\n", params)

#     # r = requests.post(url, data=params, headers={
#     #                   "Authorization": "Bearer " + ACCESS_TOKEN})

#     params = {"id": 0, "designation": "HIBERNUS GRANDE CUVÉE VINTAGE BRUTO", "amountInStock": 1,
#               "imageUrl": "https://www.garrafinhas.pt/File/IflImage/QUJTMTkwMjEzNTI1ODAsMTE2OTY4ODcz?table=st&uniqueId=imagem&v=20200417163729&cache=True&phcversion=pt290638316", "supplier": "Garrafinhas"}

#     r = requests.post("https://aduck.rnl.tecnico.ulisboa.pt/deiparty/beverages", data=params, headers={
#         "Authorization": "Bearer " + ACCESS_TOKEN, 'Content-Type': 'application/json'})

#     print("\n\n\n", r.text, "\n", r.status_code)
