""" Collection of functions which purpose is to send requests to the API's endpoints """


""" To perform the requests, the "requests" library is used """
import requests



""" 
3 global variables are used:
    > API_URLS: dictionary that contains the URLs to send requests to;
    > ERROR: used when an error occurs;
    > ACCESS_TOKEN: some requests require an access token.
"""
from DEIParty.settings import API_URLS, ERROR, ACCESS_TOKEN


# ------------------------------------------------------------------

"""
Each function follows the same convection:
    > gets the url from the global variable;
    > fills the parameters, when necessary;
    > sends the proper request (with the parameters);
    > returns either information about the request or an error, 
      depending on the anwser of the request.
"""

def list_all_beverages(limit, offset):

    url = API_URLS["LIST_BEVERAGES"]
    params = {"limit": limit, "offset": offset}

    r = requests.get(url, params)

    return r.json() if r.ok else ERROR


def get_beverage_info(id):

    url = API_URLS["INFO_BEVERAGE"].replace("{beverageId}", str(id))

    r = requests.get(url)

    return r.json() if r.ok else ERROR


def process_removal(id):

    url = API_URLS["REMOVE_BEVERAGES"].replace("{beverageId}", str(id))

    # A header is necessary in this request
    r = requests.delete(
        url, headers={"Authorization": "Bearer " + ACCESS_TOKEN})

    # Force error 403 to pass
    if r.status_code == 403:
        return 403

    return r.status_code if r.ok else ERROR


def process_update(id, new_quantity):

    url = API_URLS["UPDATE_BEVERAGE"].replace("{beverageId}", str(id))
    
    # Gets beverage's remaining info because only beverage's quantity changes
    beverage = get_beverage_info(id)

    new_beverage = beverage
    new_beverage["amountInStock"] = new_quantity
    
    # A header is necessary in this request
    headers = {
        "accept": "application/json",
        "Authorization": "Bearer " + ACCESS_TOKEN,
        "Content-Type": "application/json"
    }

    r = requests.put(url, json=new_beverage, headers=headers)

    return r.json() if r.ok else ERROR


def process_new_bev(request):
    url = API_URLS["CREATE_BEVERAGES"]

    info = request.POST

    # Checks if "Quantidade:" is a number
    try:
        test = int(info["amountInStock"])
    except:
        return ERROR

    # assigns the values which originated from the recieved request
    params = {
        "designation": info["designation"],
        "amountInStock": int(info["amountInStock"]),
        "imageUrl": info["imageUrl"],
        "supplier": info["supplier"]
    }
    
    # A header is necessary in this request
    headers = {
        "accept": "application/json",
        "Authorization": "Bearer " + ACCESS_TOKEN,
        "Content-Type": "application/json"
    }

    r = requests.post(url, json=params, headers=headers)

    id = r.json()["id"] if r.ok else ERROR
    
    # The id is returned for the front-end rendering
    return id
