from django.urls import path
from . import views

# URL configuration module
app_name = "DEIParty"
urlpatterns = [
    path("", views.index, name="index"),
    path("beverages/<int:limit>/<int:offset>/",
         views.show_all_beverages, name="all_bev"),
    path("beverage/<int:id>/", views.show_beverage, name="show_bev"),
    path("remove_beverage/<int:id>/", views.warn_user, name="rem_bev"),
    path("remove_beverage/<int:id>/confirm_removal",
         views.confirm_removal, name="rem_bev_conf"),
    path("update_beverage/<int:id>/<int:new_quantity>",
         views.update_beverage, name="update_bev"),
    path("create_beverage/", views.create_beverage, name="create_bev"),
    path("new_beverage/", views.new_beverage, name="new_bev"),
    path("error/", views.process_error, name="proc_error")
]

# map URLs to view functions
