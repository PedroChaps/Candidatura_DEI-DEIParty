"""DEIParty URL Configuration"""

from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path("DEIParty_app/", include("DEIParty_app.urls"))
]
