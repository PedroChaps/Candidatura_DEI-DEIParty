# Candidatura a Bolsa de Iniciação à Investigação BL155/2021 - Exercício Prático

## Inicialização de um servidor local de testes

<br>

Para inicializar o servidor, é necessário que a máquina esteja equipada com:

* [python 3.8.10](https://www.python.org/downloads/) ou superior;
* Framework [Django](https://docs.djangoproject.com/en/3.2/topics/install/#installing-official-release) 3.2.7 (versão mais recente à data) ou superior;
* Módulo [requests](https://docs.python-requests.org/en/latest/) 2.26 (versão mais recente à data) ou superior;

Quando as dependências estiveram instaladas, extraía o ficheiro `.zip` e, num terminal, mova-se para a pasta extraída (`DEIParty/`) e corra o comando  
`python3 manage.py runserver --insecure`  

* (A flag `--insecure` permite visualizar os ficheiros estáticos (imagens, `.css`, ...), visto que a aplicação não está hospedada num  servidor).

Mantenha o terminal aberto e, através de um browser, aceda ao link `127.0.0.1:8000/DEIParty_app/`, a página principal da aplicação.  

Terá então acesso a toda a aplicação e às devidas interações a partir do browser, como se fosse uma página web.

<br>

--- 

## Decisões tomadas

<br>

* Apesar de não usadas, decidi manter todas as funcionalidades oferecidas pelo template criado pelo Django (como as aplicações de Admin e autenticação, base de dados, etc.) de forma a deixar a aplicação mais modular, antecipando possiveis adições dessas funcionalidades (como uma página para autenticar cada utilizador, por exemplo);


<br>

* Existiu conflito de informação na funcionalidade de atualizar uma bebida.  
O enunciado menciona a "Capacidade de **aumentar/diminuir a quantidade disponível** de uma bebida" mas a API permite atualizar outros parâmetros (o Link da imagem e fornecedor): "[Update a beverage: ID and designation cannot be modified](https://aduck.rnl.tecnico.ulisboa.pt/deiparty/swagger-ui/index.html#/default/updateBeverageById)".    

    Decidi seguir o enunciado e apenas disponibilizar a opção de atualizar a quantidade da bebida.
    
 
<br>

* Na opção de listar as bebidas, decidi que seria uma boa prática permitir ao utilizador, se quiser, não inserir um limite nem offset, pois penso que a utilização mais comum dessa funcionalidade seja visualizar todas as bebidas.
    
 
<br>

---

## Problemas com a API

<br>

Ao desenvolver a aplicação, foram encontrados 2 problemas com a API:

* Uma das suas funcionalidades é listar todas as bebidas através de uma request `GET`, podendo-se atribuir um `offset` que faz skip de `offset` bebidas: "[offset: **The number of beverages to skip before starting to collect the results**](https://aduck.rnl.tecnico.ulisboa.pt/deiparty/swagger-ui/index.html#/default/listBeverages)".  


    O que a API executa é ignorar todas as bebidas com ids menores que o `offset`, por exemplo, se `offset=4`, são ignoradas as bebidas com `id=0`, `1`, `2` e `3`.  
    
    O problema reside no facto que os ids não estão todos associados a bebidas; Ao eliminar uma bebida, o seu id não volta a ser atribuido a uma nova bebida.  
    Então, o `offset` não ignora corretamente as bebidas.

<br>   

* Outra funcionalidade da API é eliminar uma bebida, através de uma request `DELETE`.  
Porém, apenas se pode eliminar bebidas criadas pelo utilizador: "[DELETE /beverages/{beverageID}: Delete a specific beverage. **You can only delete a beverage created by yourself**](https://aduck.rnl.tecnico.ulisboa.pt/deiparty/swagger-ui/index.html#/default/deleteBeverageById)".  

    Esse comportamento confirma-se se tentar eliminar uma bebida não criada por mim, sendo retornado o erro `403`.  
    
    Contudo, existe uma forma de contrariar esse comportamento, usando uma outra funcionalidade da API: [atualizar uma bebida](https://aduck.rnl.tecnico.ulisboa.pt/deiparty/swagger-ui/index.html#/default/updateBeverageById).
    
    Ao atualizar uma bebida (que não tem que ser criada por mim), o seu criador **também é atualizado, para o utilizador que modifica a bebida**.  
    Portanto, se eu quiser eliminar uma bebida `X` não minha, basta:  
    
    1. Encontrar o id da bebida `X`;
    2. Atualizar a quantidade de garrafas da bebida `X`;
    3. Eliminar a bebida `X`. A operação (apesar de não ser o suposto) vai ser permitida e a bebida é eliminada.  
    
---

Pedro Chaparro - ist199298 - pedro.chaparro@tecnico.ulisboa.pt