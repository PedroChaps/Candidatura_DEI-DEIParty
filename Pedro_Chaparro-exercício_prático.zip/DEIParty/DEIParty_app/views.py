from django.shortcuts import render
from django.http import HttpResponse


""" 
2 global variables are used:
    > LIMIT_NR_BEV: The maximum number of beverages the API can show;
    > ERROR: used when an error occurs.
"""
from DEIParty.settings import LIMIT_NR_BEV, ERROR


"""
Multiple request functions (defined on request_functions.py) are used.
"""
from DEIParty_app.request_functions import list_all_beverages, get_beverage_info, process_removal, process_update, process_new_bev

# -----------------------------------------------------------

"""
Each function follows the same convection:
    > assigns the parameters, when necessary;
    > renders either the appropriate page or an error page, depending on the situation.
"""


# The main page
def index(request):
    
    # Gets the first available id and number of beverages currently available. 
    # Used on "index.html": 
    #   first_id - Shown as an example in placeholders for ids (So that an id that doesn't exist isn't suggested, which would be lead the user to believe the id is assigned);
    #   nr_beverages - To inform the user of how many unique beverages currently exist.
    beverages = list_all_beverages(LIMIT_NR_BEV, 0)
    
    first_id = beverages[0]["id"]
    nr_beverages = len(beverages)
    
    
    params = {"nr_beverages": nr_beverages,
              "LIMIT_NR_BEV": LIMIT_NR_BEV,
              "first_id": first_id}
              
    return render(request, "index.html", params)


# The "default" error page
def process_error(request):
    return render(request, "error_page.html")


def show_all_beverages(request, limit, offset):
    
    # Gets the beverages list from the request function
    beverages = list_all_beverages(limit, offset)
    
    params = {"beverages": beverages, "limit": limit,
              "offset": offset, "limit_p_offset": limit+offset}

    return render(request, "list_all_beverages.html", params) if beverages != ERROR else render(request, "error_page.html")


def show_beverage(request, id):

    # Gets the beverage information from the request function
    beverage = get_beverage_info(id)
    
    params = {"beverage": beverage}

    return render(request, "list_beverage.html", params) if beverage != ERROR else render(request, "error_page.html")


# Before removing a beverage, the user is warned of the action.
def warn_user(request, id):

    # First, checks if beverage exists 
    beverage = get_beverage_info(id)
    if beverage == ERROR:
        return render(request, "error_page.html")

    params = {"beverage": beverage}
    
    # Renders warn page
    return render(request, "warn_user.html", params) if beverage != ERROR else render(request, "error_page.html")


# If the user confirms the removal, he is then redirected
def confirm_removal(request, id):

    res = process_removal(id)
    
    if res == ERROR:
        return render(request, "error_page.html")
    # Special case when user tries to remove another person's beverage
    elif res == 403:
        return render(request, "removal_fail.html")
    else:
        return render(request, "removal_success.html")


def update_beverage(request, id, new_quantity):

    # fetch the old quantity first (to display to user), while also verifing if id exists
    info = get_beverage_info(id)
    if info == ERROR:
        return render(request, "error_page.html")

    old_quantity = info["amountInStock"]

    # process the update
    res = process_update(id, new_quantity)

    params = {
        "old_quantity": old_quantity,
        "new_quantity": new_quantity
    }

    # renders the page, displaying the quantity info
    return render(request, "update_beverage.html", params) if res != ERROR else render(request, "error_page.html")


def new_beverage(request):

    # The API generates an id for the newly created beverage
    id = process_new_bev(request)
    params = {"id": id}

    # Informs the user that the beverage was created successfully, displaying the id
    return render(request, "created_beverage_success.html", params) if id != ERROR else render(request, "error_page.html")
